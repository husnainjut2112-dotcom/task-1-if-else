#include <iostream>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	int age;
	 
	cout<< "Enter age:";
	cin>> age;
	
	if(age >=18)
	{
		cout <<"Result: Eligible to vote";
	}
	else
	{
	cout << "Result: Not Eligible to vote";
	}
	
	return 0;
}
